<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLawdiariesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lawdiaries', function (Blueprint $table) {
            $table->increments('id');
            $table->string('caseID')->nullable();
            $table->string('court')->nullable();
            $table->string('prevDate')->nullable();
            $table->string('nextDate')->nullable();
            $table->text('step')->nullable();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('nic')->nullable();
            $table->string('user_name')->unique();
            $table->string('dob')->nullable();
            $table->string('gender')->nullable();
            $table->string('phone')->nullable();
            $table->string('password')->nullable();
            $table->string('no')->nullable();
            $table->string('street')->nullable();
            $table->string('role')->nullable();              
            $table->string('city')->nullable();
            $table->string('email')->nullable();
            $table->string('case_type')->nullable();
            $table->string('case_num')->nullable();
            $table->string('lawyer')->nullable();
            $table->string('pic')->nullable();
            $table->text('desc')->nullable();           
            $table->string('status')->default(0);
            $table->string('active')->default(0);
            $table->string('status02')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lawdiaries');
    }
}
