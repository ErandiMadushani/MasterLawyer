<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGiftdeedsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('giftdeeds', function (Blueprint $table) {
            $table->increments('id');
            $table->string('c_rs01');
            $table->string('L_num');
            $table->string('date01');
            $table->string('another');
            $table->string('no');
            $table->string('donar_name');
            $table->string('donar_address');
            $table->string('donee_name01');
            $table->string('donee_address');
            $table->string('donee_name02');
            $table->string('c_rs02');
            $table->string('donee_name03');
            $table->string('date02');
            $table->rememberToken();
            $table->timestamps();            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('giftdeeds');
    }
}
