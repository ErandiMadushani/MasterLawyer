<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lawdiary extends Model
{
    //
}
