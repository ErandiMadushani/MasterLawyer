<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Giftdeed extends Model
{
    public $table = "giftdeeds";
}
