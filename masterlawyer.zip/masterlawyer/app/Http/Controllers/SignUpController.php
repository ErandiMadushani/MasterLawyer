<?php

namespace App\Http\Controllers;
use\App\User;
use\App\Giftdeed;
use\App\lawdiary;
use\App\File;
use DB;
use\App\Message;
use\App\Appointment;
use\App\Payment;
use Illuminate\Http\Request;
use\Illuminate\Support\Facades\Auth;

class SignUpController extends Controller
{
    public function getSignup(){
        return view('signup');
    
}
public function indexhome(){
    return view('welcome');
}
public function getwelcome(){
    return view('welcome');
}
public function getadmin(){  
    $user = Auth::user();    
    return view('admin')->with('users',$user); 
}
public function getadmindash(){      
    return view('admindash'); 
}
public function getadminapprove(){      
    return view('adminapprove'); 
}
public function deletetask($id){
    $user=User::find($id);
     $user->delete();
    return redirect()->back();

}
public function deletecustask($id){
    $user=User::find($id);
     $user->delete();
    return redirect()->back();

}
public function viewtasks($id){
    $user=User::find($id);
    return view('view')->with('taskdata',$user);
}

public function viewcases($id){
    $user=User::find($id);
    return view('caseview')->with('casedata',$user);
}
public function viewcasesup($id){
    $user=User::find($id);
    return view('caseupview')->with('casedata',$user);
}
public function conveyviewtasks($id){
    $giftdeed=Giftdeed::find($id);
    return view('viewconvey')->with('conveydata',$giftdeed);
}
public function getloginform(){
    return view('loginform');
}
public function getlawyermessage(){
    return view('lawyermessage');
}
public function getclerk(){
    return view('clerk');
}
public function getconvey(){
    return view('convey');
}
public function getaddcasedata(){
    return view('addcasedata');
}
public function getclerkhome(){
    return view('clerkhome');
}
public function getlawyerdash(){
    $user = Auth::user();    
    return view('lawyerdash')->with('users',$user); 
}
public function getuploadimage(){
    return view('uploadimage');
}
public function signup(){
    return view('signup');
}
public function getgiftdeed(){
    return view('giftdeed');
}
public function getlawdiary(){
    return view('lawdiary');
}
public function getaboutus(){
    return view('aboutus');
}
public function getpractices(){
    return view('practices');
}
public function getlawyerProfile(){
    return view('lawyerProfile');
}
public function getassetBased(){
    return view('assetBased');
}
public function getworkouts(){
    return view('workouts');
}
public function getcollection(){
    return view('collection');
}
public function getrealEstateTransaction(){
    return view('realEstateTransaction');
}
public function getcontracts(){
    return view('contracts');
}
public function getcoparate(){
    return view('realEstateTransaction');
}
public function getcrossBoader(){
    return view('crossBoader');
}
public function getcommercialLaw(){
    return view('commercialLaw');
}
public function getlawcustomer(){   
    return view('lawcustomer');
}
public function getuser(){   
    return view('user');
}
public function getsendmessage(){   
    return view('sendmessage');
}
public function getreadmessage(){   
    return view('readmessage');
}
public function getpayment(){   
    return view('payment');
}
public function getpayment02(){   
    return view('payment02');
}
public function getadminmail(){
    return view('adminmail');
}
public function getadminsendmsg(){
    return view('adminsendmsg');
}
public function getlawadminpay(){
    return view('lawadminpay');
}
public function getviewdaytask(){
    return view('viewdaytask');
}
public function getsendmessagereq(){
    return view('sendmessagereq');
}
public function updatepays($id){
    $user=User::find($id);
    return view('payment02')->with('taskdata',$user);
}
public function viewtaskmessages($id){
    $message=Message::find($id);
    $message->status=1;
    $message->save();
    return redirect()->back();
 

}
public function viewtaskcusmessages($id){
    $message=Message::find($id);
    $message->active=0;
    $message->save();
    return redirect()->back();
 

}
public function postDeed(Request $request){
    $c_rs01=$request['c_rs01'];
    $L_num=$request['L_num'];
    $date01=$request['date01'];
    $another=$request['another'];
    $no=$request['no'];
    $donar_name=$request['donar_name'];
    $donar_address=$request['donar_address'];
    $donee_name01=$request['donee_name01'];
    $donee_address=$request['donee_address'];
    $donee_name02=$request['donee_name02'];
    $c_rs02=$request['c_rs02'];
    $donee_name03=$request['donee_name03'];
    $date02=$request['date02'];

    $giftdeed=new Giftdeed();
    $giftdeed->c_rs01=$c_rs01;
    $giftdeed->L_num=$L_num;
    $giftdeed->date01=$date01;
    $giftdeed->another=$another;
    $giftdeed->no=$no;
    $giftdeed->donar_name=$donar_name;
    $giftdeed->donar_address=$donar_address;
    $giftdeed->donee_name01=$donee_name01;
    $giftdeed->donee_address=$donee_address;
    $giftdeed->donee_name02=$donee_name02;
    $giftdeed->c_rs02=$c_rs02;
    $giftdeed->donee_name03=$donee_name03;
    $giftdeed->date02=$date02;
    $giftdeed->save();
    return redirect()->route('admin');

}
// public function postImage(Request $request){
//     $admin = User::create([
//         'admin_id' => $request->admin_id,
//         'f_name' => $request->fullName,
//     ]);}
public function postImage(Request $request) {
    // $this->validate($request, [
    //     'input_img' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
    // ]);
    $upload=new Upload();
    $upload->deed_number = $request->deed_number;
    $upload->type_deed = $request->type_deed;
    $upload->save();
    if ($request->hasFile('input_img')) {
        $image = $request->file('input_img');
        $name = time().'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/img');
        $image->move($destinationPath, $name);
        $this->save();

        return back()->with('success','Image Upload successfully');
    }
}

public function postSignUp(Request $request){

    $this->validate($request,  [
        'first_name'=>'required|max:20',
        'last_name'=>'required|max:20',
        'user_name'=>'required|min:4|unique:users',
        'phone'=>'required|min:10',
        'dob'=>'required|nullable|date'
        
        ]);
        //desc
    $first_name=$request['first_name'];
    $last_name=$request['last_name'];
    $user_name=$request['user_name'];
    $nic=$request['nic'];
    $dob=$request['dob'];
   $phone=$request['phone'];
    $password=bcrypt($request['password']);
    $gender=$request['gender']? 1:0;
     $no=$request['no'];
     $street=$request['street'];
    $city=$request['city'];
    $email=$request['email'];
    $role=$request['role'];
    $lawyer=$request['lawyer'];
   $regno=$request['regno'];
   $desc=$request['desc'];

    $user=new User();
    $user->first_name=$first_name;
    $user->last_name=$last_name;
    $user->user_name=$user_name;
    $user->nic=$nic;
    $user->dob=$dob;
 $user->phone=$phone;
    $user->password=$password;
    $user->gender=$gender;
    $user->no=$no;
    $user->street=$street;
    $user->city=$city;
    $user->email=$email;
   $user->role=$role;
   $user->lawyer=$lawyer;
  $user->regno=$regno;
  $user->desc=$desc;

        $user->save();
    return redirect()->route('loginform');
    $user=User::all();
 
}
public function updateTaskAsCompleted($id){
    $user=User::find($id);
    $user->active=1;
    $user->save();
    return redirect()->back();

}
public function updateTaskAsNotCompleted($id){
    $user=User::find($id);
    $user->active=0;
    $user->save();
    return redirect()->back();

}

public function updateTaskAsadminCompleted($id){
    $user=User::find($id);
    $user->approve=1;
    $user->save();
    return redirect()->back();
}
public function updateTaskAsNotadminCompleted($id){
    $user=User::find($id);
    $user->approve=0;
    $user->save();
    return redirect()->back();
}
public function store(Request $request)
{
    $this->validate($request, [
            'filenames' => 'required',
            'filenames.*' => 'mimes:doc,pdf,docx,zip,jpeg'
    ]);
    if($request->hasfile('filenames'))
     {
        foreach($request->file('filenames') as $file)
        {
            $name=$file->getClientOriginalName();
            $file->move(public_path().'/files/', $name); 
            $data[] = $name;  

        }

     }


     $file= new File();
     $file->filenames=json_encode($data);

     $file->deed_number=$request->deed_number;
     $file->type_deed=$request->type_deed; 
     $file->save();


    return back()->with('success', 'Data Your files has been successfully added');

}



public function postLogin(Request $request){
    $this->validate($request,  [
            
        'user_name'=>'required|min:2|',
        'password'=>'required|min:2|',
       // 'g-recaptcha-response' => 'required|captcha',
        
      
        ]);
        if (Auth::attempt(['user_name' => $request['user_name'], 'password' => $request['password'],'role' => "Lawyer",'active'=>1,'approve' => 1])) {
            return redirect()->route('admin');
        }
        if (Auth::attempt(['user_name' => $request['user_name'], 'password' => $request['password'],'role' => "Lawyer",'active'=>1,'approve' => 0])) {
            return redirect()->route('lawyerdash');
        }
        if (Auth::attempt(['user_name' => $request['user_name'], 'password' => $request['password'],'role' => "Clerk",'active'=>1])) {
            return redirect()->route('clerkhome');
        }
        if (Auth::attempt(['user_name' => $request['user_name'], 'password' => $request['password'],'role' => "Customer",'active'=>1])) {
            return redirect()->route('user');
        }
        
        return redirect()->back()->with('message02','Login Failed please check user name and password');
}
public function getLogout(){
    Auth::logout();
    return redirect()->route('welcome');

}
public function postlawdiaryaddcasedata(Request $request){
   
    $caseID=$request['caseID'];
    $court=$request['court'];
    $prevDate=$request['prevDate'];
    $nextDate=$request['nextDate'];
    $step=$request['step'];
    $lawyer=$request['lawyer'];

    $lawdiary=new lawdiary();
    $lawdiary->caseID=$caseID;
    $lawdiary->court=$court;
    $lawdiary->prevDate=$prevDate;
    $lawdiary->nextDate=$nextDate;
    $lawdiary->step=$step;
    $lawdiary->lawyer=$lawyer;
        $lawdiary->save();
    return redirect()->route('admin');
    $lawdiary=lawdiary::all();
 
}
public function postmessagenew(Request $request){
   
    $first_name=$request['first_name'];
    $last_name=$request['last_name'];
    $email=$request['email'];
    $lawyer=$request['lawyer'];
    $msg=$request['msg'];
  

    $message=new Message();
    $message->first_name=$first_name;
    $message->last_name=$last_name;
    $message->email=$email;
    $message->lawyer=$lawyer;
    $message->msg=$msg;
    $message->save();
    return redirect()->route('admin');
    $message=Message::all();
 
}
public function postaddmessagenew(Request $request){
   
    $first_name=$request['first_name'];
    $last_name=$request['last_name'];
    $email=$request['email'];
    $lawyer=$request['lawyer'];
    $msg=$request['msg'];
  

    $message=new Message();
    $message->first_name=$first_name;
    $message->last_name=$last_name;
    $message->email=$email;
    $message->lawyer=$lawyer;
    $message->msg=$msg;
    $message->active=1;
    $message->save();
    return redirect()->route('admin');
    $message=Message::all();
 
}
// public function postsavepayment(Request $request){
   
//     $lawyer=$request['lawyer'];
//     $customer=$request['customer'];
//     $reason=$request['reason'];
//     $fee=$request['fee'];
    
  

//     $payment=new Payment();
//     $payment->lawyer=$lawyer;
//     $payment->customer=$customer;
//     $payment->reason=$reason;
//     $payment->fee=$fee;

//     $payment->save();
//     return redirect()->route('payment');
//     $payment=Payment::all();
 
// }
public function paymenttask(request $request){
    $id=$request->id;

    $first_name=$request->first_name;
    $last_name=$request->last_name;
    $cus_first_name=$request->cus_first_name;
    $cus_last_name=$request->cus_last_name;
    $nic=$request->nic;
    $reason=$request->reason;
    $fee=$request->fee;
    
    $payment=new Payment();
    
     $payment->first_name=$first_name;
     $payment->last_name=$last_name;
     $payment->cus_first_name=$cus_first_name;
     $payment->cus_last_name=$cus_last_name;
     $payment->nic=$nic;
     $payment->reason=$reason;
     $payment->fee=$fee; 
     $payment->lawfee=$fee*0.8;     
     $payment->firmfee=$fee*0.2;    
     $payment->save();
     $payments=Payment::all();
     return view('user');  
}
public function postsendreq(Request $request){
   
    $law_first_name=$request['law_first_name'];
    $law_last_name=$request['law_last_name'];
    $nic=$request['nic'];
    $cus_first_name=$request['cus_first_name'];
    $cus_last_name=$request['cus_last_name'];
    $des=$request['des'];

    $appointment=new Appointment();
    $appointment->law_first_name=$law_first_name;
    $appointment->law_last_name=$law_last_name;
    $appointment->nic=$nic;
    $appointment->cus_first_name=$cus_first_name;
    $appointment->cus_last_name=$cus_last_name;
    $appointment->des=$des;
    $appointment->save();
    return redirect()->route('user');
    $appointment=Appointment::all();
 
}
}