<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use\App\User;
use\App\Giftdeed;
use\App\File;
use\App\CaseFile;
class CaseController extends Controller
{
    public function postcaseupdate(Request $request){  
$casefile=new CaseFile();
$casefile->first_name=$request->first_name;
// $casefile->id=$request->id;
$casefile->last_name=$request->last_name;
$casefile->nic=$request->nic;
$casefile->user_name=$request->user_name;
$casefile->dob=$request->dob;
$casefile->phone=$request->phone;
$casefile->gender=$request->gender;
$casefile->no=$request->no;
$casefile->street=$request->street;
$casefile->city=$request->city;
$casefile->email=$request->email;
$casefile->role=$request->role;
$casefile->lawyer=$request->lawyer;
$casefile->desc=$request->desc;
$casefile->case_type=$request->case_type;
$casefile->case_num=$request->case_num;
$casefile->save();
return redirect()->route('cases');
    }
}
