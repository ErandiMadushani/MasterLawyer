<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer Home</title>
	<!--link rel="stylesheet" type="text/css" href="style1.css"-->
<style type="text/css">
	*{
	margin: 0;
	padding: 0;
	font-family: sans-serif;
}
/* header photo*/
header{
	background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(img/10.jpg);
	background-size: cover;
	background-position: center;
	width: 100%;
	height: 300px;
}
/*master lawyer title*/																					/*  phone */
.title{
	position: absolute;
	top: 20%;
	left:49%;
	transform: translate(-50%,-50%);	
} 

.title h2{
	color: #fff;
	font-size: 26px;
	font-family: Century Gothic;
}
/*  navigation bar*/
ul{
	float: right;
	list-style-type: none;
	margin-top: 25px;
	font-size: 16px;
}

ul li{
	display: inline-block;
}

ul li a{
	text-decoration: none;
	color: #fff;
	padding: 2px 8px; 
	border: 1px solid transparent;	
	transition: 0.6s ease;
}

ul li a:hover{
	background-color: #fff;
	color: #000;
}

ul li.active a{
	background-color: #fff;
	color: #000;
}
/* button below the title*/
.button{
	position: absolute;
	top: 25%;
	left:49%;
	transform: translate(-50%,-50%);
}

.btn{
	border: 1px solid #fff;
	padding: 5px 10px;
	color: #fff;
	text-decoration: none;
	font-size: 14px;
}

.btn:hover{
	font-weight: bold;
}
/* logo image*/
.logo-img1{
	width: 60%;
	margin-top: 30px;
	margin-left: 80px;

}
/* description*/
.content{
	margin-top: 20px;
	margin-left: 40px;
	margin-right: 30px;
	line-height: 24px;
}

.content p{
	text-align: justify;
	color: gray;
}

.container3 {
  max-width: 94%;
  position: relative;
  /*margin: auto;*/
  margin-top: 80px; 
}

/*theme transparent*/

.text {
 /* color: #f2f2f2;*/
  color: #fff;
  font-size: 50px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
  background-color: #001a33;
  margin-top: 100px;
  font-weight: bold;
}

.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 10;
}

.dot {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: black;
}

.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes  fade {
  from {opacity: .4} 
  to {opacity: 1}
}
/* footer*/
.footer{
	background-color: #00001a;
	margin-top: 8%;
	height: 50%;
	color: #fff; 
}
/* contact us */
.contact{
	color: #fff;
	margin:20px 50px 10px 50px;
	padding-top: 20px;
 	font-size: 20px;
 	font-weight: bold;
}

/* fa fa icons*/
i{
	 font-size:24px;
	 color: #fff; 
	 padding-left: 70px;
	}
/* footer details*/
.footer p{
	color: #fff;	
 }

hr{
	background-color: black;
	margin-top: 60px;
}

.practiceAreas h2{
	text-align: center;
	margin-top: 40px;
	margin-bottom: 60px;
	font-size: 60px;
	color: #000066;
}

.practiceAreas img{
	margin-top: 50px;
	margin-left: 50px;
}

.practiceAreas p{
	margin-left: 50px;
	margin-top: 50px;
}



 @media  only screen and (min-width: 768px){				/* tablets */

 	header{
	height: 500px;
}

	.title{
	top: 23%;
} 


.button{
	top: 27%;
	
}

.content p{
	font-size: 20px;
	line-height: 24px;
}

.btn{
	font-size: 18px;
}

.logo-img1{
	width: 50%;
	margin-top: 30px;
	margin-left: 190px;
}

.container3{
	max-width: 99%;
}


.text {
  width: 97%;
}

.title h2{
	font-size: 30px;
}

ul{
	font-size: 20px;
}

.practices h2{
	margin-top: 70px;
	font-size: 58px;
	margin-bottom: 70px;
}

.practices img{
	margin-left: 250px;
}


.practices p{
	margin-left: 350px;
	margin-top: 20px;
	margin-bottom: 20px;
	font-size: 20px;
}

 }


@media  only screen and (min-width: 1000px){				/* computers */
	header{
	height: 760px;
}

.title{
	top: 50%;
} 

.title h2{
	font-size: 50px;
}

.button{
	top: 59%;
}

.btn{
	font-size: 20px;
	padding: 10px 20px;
}

ul{
	font-size: 20px;
}

ul li a{
	padding: 8px 10px 8px 10px; 
	margin: 0px 10px 10px 10px; 
}

.logo-img1{
	width: 400px;
	height: 400px;
	margin: 80px 80px 0px 200px;
	float: left;
}

.content{
	margin: 100px 200px 130px 100px;

}

.text {
  width: 98%;
}

.footer{
	height: 350px;
}

.container3{
	max-width: 100%;
}

hr{
	height: 2px;
}




}


</style>




	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	

</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
				<li class="active"><a href="/welcome">Home</a></li>
				<li><a href="/practices">Basic Law</a></li>
				<li><a href="/aboutus">About Us</a></li>
				<li><a href="/loginform">Login</a></li>


		<div class="title">
			<h2>MASTER LAWYER</h2>
		</div>

		<div class="button">
			<a href="/practices" class="btn">PRACTICES</a>
			<a href="/lawyerProfile" class="btn">OUR TEAM</a>
		</div>
		
	</header>

<div class="logo-img">
	<img class="logo-img1" src="img/29.jpg">
</div>

<div class="content">
				
			<p> 

We offer assistance in any legal matters related to immigration and residence in Sri Lanka.<br><br>

We can assist in the preparation and filing of all required documents for short-term, long-term and permanent residency in Sri Lanka, as well as obtaining a Bulgarian visa (including a Type D Visa).<br><br>

We also provide consultation services to our clients in Sri Lankan citizenship cases.<br><br>

We can assist our clients to obtain Sri Lankan citizenship by participating in the Investment Citizenship Program.<br><br>

And in event that you have decided to live in or to move your business to UK or USA, we would also be glad to recommend our partners law offices there.
</p>
	
		</div>
<br><br>
<div class="container3">

			<div class="mySlides fade">
  				
  			<div class="text">We Listen</div>
			</div>

			<div class="mySlides fade">
  			<div class="text">We fight</div>
			</div>

			<div class="mySlides fade">
  			<div class="text">You Win</div>
			</div>

		</div>

		<div style="text-align:center">
  			<span class="dot"></span> 
  			<span class="dot"></span> 
  			<span class="dot"></span> 
		</div>
		<div class="practiceAreas">
			<h2>Practice Areas</h2>
			
			<a href="/workouts"><img src="css/img/54.jpg"></a>
			
			
			<a href="/assetBased"><img src="img/55.jpg"></a>

			<a href="/collection"><img src="img/56.jpg"></a>
			
			<a href="/commercialLaw"><img src="img/57.jpg"></a> 
			
			<a href="/realEstateTransaction"><img src="img/58.jpg"></a>
	
			<a href="/contracts"><img src="img/59.jpg"></a>
			
			<a href="/coparate"><img src="img/60.jpg"></a>
		
			<a href="/crossBoader"><img src="img/61.jpg"></a>
			
			
		</div>



<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>





<script>
		var slideIndex = 0;
		showSlides();

		function showSlides() {
 		 var i;
  		 var slides = document.getElementsByClassName("mySlides");
  		 var dots = document.getElementsByClassName("dot");
  		  for (i = 0; i < slides.length; i++) {
    		slides[i].style.display = "none";  
  			}
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
</script>


</body>
</html>