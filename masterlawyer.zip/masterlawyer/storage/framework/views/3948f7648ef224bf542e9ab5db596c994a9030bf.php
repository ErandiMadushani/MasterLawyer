<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Master Lawyer</title>

  
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    
	


     <style>
              td{

              color: black;
             

           }
		   th{
		      color:black;
			   font-weight: bold;
		   }
		   p.solid {border-style: solid;}

          p{
		     padding:15px;
		  
		  }
		   #just {
               text-align: justify;
               text-justify: inter-word;
			   padding-top:15px;
               }
			   
			   form.example button:hover {
  background: #0b7dda;
}

              form.example::after {
  content: "";
  clear: both;
  display: table;
}
                 
				 form.example button {
  float: left;
  width: 5%;
  padding: 2px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
  margin-top:23px;
}

    form.example input[type=text] {
  padding: 2px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 95%;
  background: #f1f1f1;
  margin-top:23px;
}
     .btn_eye{
	 
	     background-color:yellow;
		 height:35px;
		 width:35px;
		 border-radius:5px;
	 
	 }
     .btn_print{
	     background-color:#4286f4;
		 height:35px;
		 width:35px;
		 border-radius:5px;
	 }
	 
	 .btn_close{
	     background-color:#f43f3f;
		 height:35px;
		 width:35px;
		 border-radius:5px;
	 }
	 input[type=text] {
  width: 100%;
  padding: 12px 20px;
  margin: 1px 0;
  box-sizing: border-box;
	border:none; 
      </style>
	  
</head>

<body>
  <section id="container">
    
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Master<span>Lawyer</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="login.html">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">S.P.L.Herasinghe</h5>
          <li class="mt">
            <a href="index.html">
              <i class="fa fa-home"></i>
              <span>Home</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-male"></i>
              <span>Customers</span>
              </a>
           
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Cases</span>
              </a>
            <ul class="sub">
              <li><a href="grids.html">View Cases</a></li>
              <li><a href="calendar.html">Update Cases</a></li>
              
              
              
            </ul>
          </li>
          <li class="sub-menu">
            <a class="active" href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Conveyance</span>
              </a>
            <ul class="sub">
              <li class="active"><a href="Lawyer_side_convayance_01_save.html">Gift Deed</a></li>
              <li><a href="login.html">Convay 02</a></li>
              <li><a href="Lawyer_side_convayance_01_view_image_up.html">Upload image of Deed</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Evidance</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.html">E 01</a></li>
              <li><a href="advanced_form_components.html">E 02</a></li>
              <li><a href="form_validation.html">E 03</a></li>
              <li><a href="contactform.html">E 04</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Law Diary</span>
              </a>
            
          </li>
          <li>
            <a href="inbox.html">
              <i class="fa fa-envelope"></i>
              <span>Mail </span>
              <span class="label label-theme pull-right mail-info">2</span>
              </a>
          </li>
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
   
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        
        
		  
        <div class="row mt">
          <div class="col-lg-12">
                 <h3>Send your message to the lawyer</h3>  
				 
              
          
                       <form class="example" action="/action_page.php">
                       <input type="text" placeholder="Search your lawyer here..." name="search">
                      <button type="submit"><i class="fa fa-search"></i></button>
                        </form>
						
						</br>
						</br>
					   
					   
      <form class="form-horizontal" action="/action_page.php">
      
      <div class="form-group">
      <div class="table-responsive">
      <table class="table table-striped">
         <thead>
      <tr>
        <th>No. </th>
		<th>Message From </th>
        <th>Messege </th>
        
       
                
				
                <th>Action</th>

        
      </tr>
         </thead>
     <tbody>		 
      <tr>
        <td></td>
		<td></td>
        <td></td>
        
        
       <td><button type="button" class="btn btn-primary">Read</button>
                </td>
       
                
      </tr>     
         </tbody>  
      </table>
              
        </div>    
      
    </div>
  </form>
          </div>
        </div>
						
						
			
          </div>
        </div>
      
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
   
  </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
   
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <script src="css/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="css/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="css/jquery.dcjqaccordion.2.7.js"></script>
  <script src="css/jquery.scrollTo.min.js"></script>
  <script src="css/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="css/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
