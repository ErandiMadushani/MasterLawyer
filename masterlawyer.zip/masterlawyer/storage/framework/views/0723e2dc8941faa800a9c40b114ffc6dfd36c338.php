<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer Profiles</title>
	<link rel="stylesheet" type="text/css" href="css/style7.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style>

        *{
	   box-sizing:border-box;
	
	}
	.row::after {
    content: "";
    clear: both;
    display: block;
}
 [class*="col-"] {
    float: left;
    padding: 20px;
	
	}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.card p{
	margin-top: 20px;
}

.card i{
	color: black;
	padding-left: 2px;
}

.title {
  color: #2F4F4F;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #1E90FF;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
  
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}

h1{
  color:#1E90FF;

}


/* For desktop: */
.col-1 {width: 8.33%;}
.col-2 {width: 16.66%;}
.col-3 {width: 25%;}
.col-4 {width: 33.33%;}
.col-5 {width: 41.66%;}
.col-6 {width: 50%;}
.col-7 {width: 58.33%;}
.col-8 {width: 66.66%;}
.col-9 {width: 75%;}
.col-10 {width: 83.33%;}
.col-11 {width: 91.66%;}
.col-12 {width: 100%;}

@media  only screen and (max-width: 768px) {
    /* For mobile phones: */
    [class*="col-"] {
        width: 100%;
    }

</style>
	
</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
				<li><a href="home_10.html">Home</a></li>
				<li><a href="Practices.html">Basic Law</a></li>
        <li><a href="aboutus.html">About Us</a></li>
        <li><a href="signIn.html">Login</a></li>
				
			</ul>
		<div class="title">
			<h2>Lawyers</h2>
		</div>

</header>


<div class="content">
	<div>			
			<h2 style="text-align:center">User Profile Card</h2>
<div class="column1 col-3">
<div class="card">
<a href="#"><img src="img/30.jpg" alt="John" style="width:100%"></a>
  
  <h1>Shihan Chathuranga</h1>
 <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>

<div class="column2 col-3">
<div class="card">
<a href="#"><img src="css/img/72.jpg" alt="John" style="width:100%"></a>
  <br><br><br><br>
  <h1>Subashini Jayawardana </h1>
  <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 28px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>


<div class="column2 col-3">
<div class="card">
<a href="#"><img src="css/img/71.jpg" alt="John" style="width:100%"></a>
  <br><br><br><br>
  <h1>Lasun Basnayaka</h1>
  <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>


<div class="column2 col-3">
<div class="card">
<a href="#"><img src="css/img/70.jpg" alt="John" style="width:100%"></a>
  <br><br><br><br>
  <h1>Kasun Gunarathna</h1>
  <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>
<!--
<div class="column1 col-3">
<div class="card">
<a href="#"><img src="images/1.jpg" alt="John" style="width:100%"></a>
  
  <h1>John Doe</h1>
 <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>

<div class="column1 col-3">
<div class="card">
<a href="#"><img src="images/1.jpg" alt="John" style="width:100%"></a>
  
  <h1>John Doe</h1>
 <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>

<div class="column1 col-3">
<div class="card">
<a href="#"><img src="images/1.jpg" alt="John" style="width:100%"></a>
  
  <h1>John Doe</h1>
 <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>

<div class="column1 col-3">
<div class="card">
<a href="#"><img src="images/1.jpg" alt="John" style="width:100%"></a>
  
  <h1>John Doe</h1>
 <p class="title"></p>
  <p>Areas of practices</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
  </div>
  <p><button type="button" class="btn btn-primary">Show Contact Information</button></p>
</div>
</div>
-->
		
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

</div>
</div>

<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>

</body>
</html>