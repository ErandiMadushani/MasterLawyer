<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Master Lawyer</title>

  
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    
	


      <style>
              td{

              color: black;
             

           }
		   th{
		      color:black;
			   font-weight: bold;
		   }
		   #solid {
        border-style: solid;
        border-radius: 5px;
        background-color: #e1e8f4;
        border-width: 1px;
        padding-top: 15px;
        border-color: white;
        padding-right: 5px;
       
       }

       input{

           
           height: 30px;
           width: 200px;
           border-style: 1px;
       }

      

       textarea{
            
           height: 60px;
           width: 200px;
           border-style: 1px;


       }

       h7{
         
           font-size: 16px;
           font-weight: bold;
           padding-left: 15px;
       }

          h3{
		     
         text-align: center;
         color: black;
         font-weight: bold;
		  
		  }

      .fa-save {
             font-size:20px;
           color:white;
           background-color:#4482ed;  
           padding:10px;
           border-radius: 5px;
           border-color: black;
         
         }
         
         .btn{
           
            border-radius: 5px;
            float: right;
            padding: 1px;
            margin-right: 15px;
            margin-left: 15px;
         
         }

        button:hover {
  background: #0b7dda;
}

              form.example::after {
  content: "";
  clear: both;
  display: table;
}
    
    select{

         padding-left: 5px;
           margin-left: 100px;
           margin-right: 20px;
           height: 30px;
           width: 665px;
           border-style: none;
    }    
        #serch_btn{
           float: left;
           width: 5%;
            padding: 2px;
            background: #2196F3;
            color: white;
             font-size: 17px;
             border: 1px solid grey;
             cursor: pointer;
              margin-left: -110px;
}         
          

     #select {
 
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  background: #f1f1f1;
 padding-left: 5px;
           margin-left: 100px;
           margin-right: 100px;
           height: 30px;
           width: 628px;
          
}

		   #just {
               text-align: justify;
               text-justify: inter-word;
			   padding-top:15px;
               }
			   
			 
     .btn_eye{
	 
	     background-color:yellow;
		 height:35px;
		 width:35px;
		 border-radius:5px;
	 
	 }
    .btn_check{
           border-radius: 5px;
            float: right;
            padding: 8px;
            margin-right: 165px;
            margin-left: 15px;
            background-color: green;
            color: white;
            font-size: 18px;

    }
	 
	 .btn_close{
	     border-radius: 5px;
            float: right;
            padding: 9px;
            margin-right: 65px;
            margin-left: 40px;
            background-color: red;
            color: white;
            font-size: 18px;

	 }
	 
     button{
         width: 200px;
     }

      </style>
	  
	  
 
</head>

<body>
  <section id="container">
    
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Master<span>Lawyer</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
        <li><a class="logout" href="<?php echo e(route('logout')); ?>">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <?php if( auth()->check() ): ?>
          <h5 class="centered"><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></h5>
          <li class="mt">
          <?php endif; ?>
          <h5 class="centered">M.G.E.M.Jayathilaka</h5>
          <li class="mt">
            <a href="index.html">
              <i class="fa fa-home"></i>
              <span>Home</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-male"></i>
              <span>Chat with your Lawyer</span>
              </a>
           
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Pay Your Lawyer Fee</span>
              </a>
            
          </li>
          
          
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
   
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        
        
		  
        <div class="row mt">
          <div class="col-lg-12">

          <h2>Payment for Lawyer</h2><br><br>
         <div class="table-responsive">        
          <table class="table">
    <thead>
      <tr>
        <th>First name</th>
        <th>Last name</th>
        <th>ID number</th>        
        <th></th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>    
     
       
        <td><?php echo e($user->first_name); ?> </td> 
        <td><?php echo e($user->last_name); ?> </td>
        <td><?php echo e($user->nic); ?></td>
        <td><a button type="button" href="/updatepay/<?php echo e($user->id); ?>" class="btn btn-success">Pay here</button></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </thead>
    <tbody>
      

  </table>	 
    </div>

          </div>
        </div>
						
						
			
          </div>
        </div>
      
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
   
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <script src="css/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="css/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="css/jquery.dcjqaccordion.2.7.js"></script>
  <script src="css/jquery.scrollTo.min.js"></script>
  <script src="css/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="css/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
