<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Master Lawyer</title>

  
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    


      <style>
              td{

              color: black;
              font-weight: bold;

           }
		   .solid {border-style: solid;}

          h3{
		     padding:15px;
			 margin-left:300px;
		  
		  }
		   #just {
               text-align: justify;
               text-justify: inter-word;
			   padding-top:15px;
               }
			   
			   #Number{
			       margin-left:550px;
				   
			   }
			   
			   #pcontent,#pcontent2{
			      padding-left:15px;
				  padding-right:15px;
			   
			   }
			   
			   h1{
			      font-size:38px;
				  padding-left:35px;
				  padding-right:15px;
			   }
			   #date{
			    padding-left:15px;
				  padding-right:15px;
			   }
			   
			    h4{
			      padding-left:300px;
				  
			   
			   }
			   
			   #topic{
			      font-family:Old English Text MT;
				  font-weight:bold;
				  font-size:30px;
				  padding-left:200px;
			   }
			   hr{
			    border: 1px solid black;
			   
			   }
			   h5{
			      font-weight:bold;
				  padding-left:15px;
				  padding-right:15px;
			   }
			   .fa-save {
			       font-size:20px;
				   color:white;
				   background-color:#4286f4;  
				   padding:10px;
			   }
			   
			   .fa-print {
			       font-size:20px;
				   color:white;
				   background-color:green;  
				   padding:10px;
			   }
			   
			   .btn{
			      padding:5px;
				  align:right;
			   
			   }
			   
			   #inp{
			      width:400px;
				  height:50px;
			   }
			   #inpt{
			      width:300px;
				  height:30px;
			   }
			  
			<!--.print{
			     font-family: sans-serif;
				 margin-left:810px;
			 
			 }-->
      </style>
	  
	  
 
</head>

<body>
  <section id="container">
    
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Master<span>Lawyer</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="login.html">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">S.P.L.Herasinghe</h5>
          <li class="mt">
            <a href="index.html">
              <i class="fa fa-home"></i>
              <span>Home</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-male"></i>
              <span>Customers</span>
              </a>
           
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Cases</span>
              </a>
            <ul class="sub">
              <li><a href="grids.html">Criminal</a></li>
              <li><a href="calendar.html">Civil</a></li>
              <li><a href="gallery.html">Divoce</a></li>
              <li><a href="todo_list.html">Case 01</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a class="active" href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Conveyance</span>
              </a>
            <ul class="sub">
              <li class="active"><a href="Lawyer_side_convayance_01_save.html">Gift Deed</a></li>
              <li><a href="login.html">Convay 02</a></li>
              <li><a href="Lawyer_side_convayance_01_view_image_up.html">Image of Deed</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Evidance</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.html">E 01</a></li>
              <li><a href="advanced_form_components.html">E 02</a></li>
              <li><a href="form_validation.html">E 03</a></li>
              <li><a href="contactform.html">E 04</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Law Diary</span>
              </a>
            
          </li>
          <li>
            <a href="inbox.html">
              <i class="fa fa-envelope"></i>
              <span>Mail </span>
              <span class="label label-theme pull-right mail-info">2</span>
              </a>
          </li>
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
   
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        
        
		  
        <div class="row mt">
          <div class="col-lg-12">
          
            <div class="col-lg-1">
			</div>
			<div class="col-lg-10 " id="just" >
      <form class="form-horizontal" method="POST" action="/savedeed">
     <?php echo e(csrf_field()); ?> 
      
      <div class="form-group">
         <div class="solid">
		    <br/>
			
			<h1>GIFT</h1><p id="Number">Consideration Rs:&nbsp;&nbsp;<input type="text" name="c_rs01"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  </P>
			<p id="Number">Lands:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="text" name="L_num"></p>
	        <p id="date">Date:<input type="date" name="date01">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Duplicate Stamps:&nbsp;&nbsp;&nbsp;<input type="text" name="another"></p>
			</br>
			<h4>No : <input type="text" name="no"></h4>
			
			<p id="topic">Know All Men by these Presents that</p></br>
			<p id="pcontent"> <input type="text" name="donar_name" placeholder="donars_name" id="inp">&nbsp;&nbsp;&nbsp; of &nbsp;&nbsp;&nbsp;
			<input type="text" name="donar_address" placeholder="donar address" id="inp"> 
			
			</br></br>
			(hereinafter sometimes called and reffered to as the donar) for and in consideration of the love and affection wich have and bear onto</br></br>
		 <input type="text" name="donee_name01" placeholder="donees name" id="inp"> &nbsp;&nbsp;&nbsp; of &nbsp;&nbsp;&nbsp;
			<input type="text" name="donee_address" placeholder="donees address" id="inp"> 
			    </br></br>
				
			
				<p id="pcontent2">
				(hereinafter sometimes called the donee) and various other considerations and hereonto moving,do hereby give,brant ,assign convey
				set cover and assure as a gift absolute and irrevocable unto the set donee <input type="text" name="donee_name02" placeholder="donees name" id="inp">
				heirs, executors, administrators and assigns all the rights, properties and premises in the Schedule hereto more fully discribed together with all and singuler
				the rights,comments literies, advantages and previlages whatever to the said premises belonging on in any wise appropriationg or usually held, 
			    occupied and enjoyed therewith or reputed to belong or known to the part and parcel thereof and all the estate,right,ritle,interrest claim and
				demand whatever of the said donar in to out of upon the said premises.
				
                </br></br></br></br>
				
				
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TO HAVE AND TO HOLD the said premisess hereby 
				conveyed which are of the value of RUPEES <input type="text" name="c_rs02" placeholder="concideration Rs" id="inpt">
				unto said donee <input type="text" name="donee_name03" placeholder="donees name" id="inp"> heirs, executors, administrators and assigns for
				ever.
				</br></br>
				
				do hereby thankfully accept the for joined gift hereby made.
				
				</br></br>
                IN WITNESS WHERE OF we the said donar and donee do not our hands to three of the same tenor and date as these presents at
				Walasmulla on this <input type="date" name="date02" placeholder="date"> 
				</br></br></br></br>
				....................................... &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;.......................................</br>
                &nbsp;&nbsp;&nbsp;Donee  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Donar
				
				</br></br></br></br>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>WITNESSES</b></br></br>
				
				signed and deliverd in the presence</br>
                of us and we declare that we are well</br>	
				acquainied with the excutants by their</br>
				propper name/occupation and residence,</br></br>
				
				.....................................................................&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				.........................................................</br></br>
				Witness 01 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Witness 2

				</p>
				
				
				
		 </div>
    </div>
	  
	  
   
      <button type="submit" class="btn"  >
	  <i class="fa fa-save" >&nbsp;&nbsp;Save</i></button>
	  
	  <button type="submit" class="btn" >
	  <i class="fa fa-print">&nbsp;&nbsp;Print</i></button>
   

	   
  </form>
      
	   
  
  </div>
      <div class="col-lg-1">
	  </div>
          </div>
        </div>
      
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
   
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <script src="css/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="css/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="css/jquery.dcjqaccordion.2.7.js"></script>
  <script src="css/jquery.scrollTo.min.js"></script>
  <script src="css/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="css/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
