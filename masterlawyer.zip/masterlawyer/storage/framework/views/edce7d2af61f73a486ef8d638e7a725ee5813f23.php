<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer Asset Based Lending</title>
	<link rel="stylesheet" type="text/css" href="css/style8.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
				<li><a href="home_10.html">Home</a></li>
				<li><a href="Practices.html">Basic Law</a></li>
				<li><a href="aboutus.html">About Us</a></li>
				<li><a href="signIn.html">Login</a></li>
				

		<div class="title">
			<h2>Asset Based Lending</h2>
		</div>

</header>


<div class="content">
				
			<p> 

Asset Based Lending team possesses a deep understanding of the objectives and legal issues involved with asset-based lending transactions.
<br><br>

Asset Based LendingOur attorneys are highly experienced in representing asset-based lenders as well as borrowing entities in a wide range of deals and specialize in the documentation, negotiation and structuring of secured asset based transactions. We represent lending institutions, non-bank commercial finance companies, investors, and borrowers.
<br><br>
Our unique business experience, coupled with an understanding of asset-based and real property transactions, allows us to provide comprehensive counsel to our clients.
<br><br>
We have a wealth of experience protecting our clients in all aspects of asset-based lending, including but not limited to creating and perfecting security interests in all types of collateral, working out and restructuring problem transactions and advising clients on the rules governing asset-based lending transactions (Revised Article 9 of the Uniform Commercial Code).
<br><br>
We have completed asset-based lending transactions all across the country and in a variety of industries. Our team seamlessly works with other practice groups, when needed, including bankruptcy, real estate, and corporate law in order to provide our clients with the services they require to close a transaction.
 <br><br>
 
		</div>
<br><br>


<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>

</body>
</html>