<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Master Lawyer</title>

  
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">




      <style>
              td{

              color: black;
              font-weight: bold;

           }

           .btn_eye{
   
       background-color:yellow;
     height:35px;
     width:35px;
     border-radius:5px;
   
   }

     .btn_close{

            background-color:red;
            height:35px;
            width:35px;
           border-radius:5px;  
           color:white; 
     }

     .btn_check{
           background-color:green;
            height:35px;
            width:35px;
           border-radius:5px;  
           color:white; 

     }

      #select {
 
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  background: #f1f1f1;
 padding-left: 5px;
           margin-left: 100px;
           margin-right: 100px;
           height: 30px;
           width: 628px;
          
}

   #serch_btn{
           float: left;
           width: 5%;
            padding: 2px;
            background: #2196F3;
            color: white;
             font-size: 17px;
             border: 1px solid grey;
             cursor: pointer;
              margin-left: -110px;
}          


      </style>
 
</head>

<body>
  <section id="container">
    
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Master<span>Lawyer</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <li><a class="logout" href="login.html">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          <h5 class="centered">S.P.L.Herasinghe</h5>
          <li class="mt">
            <a href="index.html">
              <i class="fa fa-home"></i>
              <span>Home</span>
              </a>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-male"></i>
              <span>Customers</span>
              </a>
           
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Cases</span>
              </a>
            <ul class="sub">
              <li><a href="grids.html">View Cases</a></li>
              <li><a href="calendar.html">Update Cases</a></li>
              
              
            </ul>
          </li>
          <li class="sub-menu">
            <a class="active" href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Conveyance</span>
              </a>
            <ul class="sub">
              <li class="active"><a href="Lawyer_side_convayance_01_save.html">Gift Deed</a></li>
              <li><a href="login.html">Convay 02</a></li>
              <li><a href="Lawyer_side_convayance_01_view_image_up.html">Image of Deed</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Evidance</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.html">E 01</a></li>
              <li><a href="advanced_form_components.html">E 02</a></li>
              <li><a href="form_validation.html">E 03</a></li>
              <li><a href="contactform.html">E 04</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="Lawyer_side_diary.html">
              <i class="fa fa-book"></i>
              <span>Law Diary</span>
              </a>
            
          </li>
          <li>
            <a href="inbox.html">
              <i class="fa fa-envelope"></i>
              <span>Mail </span>
              <span class="label label-theme pull-right mail-info">2</span>
              </a>
          </li>
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
   
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        
        <h3> Update cases</br></h3>
        <div class="row mt">
          <div class="col-lg-12">
          
     
      <form class="form-horizontal" action="/action_page.php">
      
      <div class="form-group">

           <input type="text" placeholder="Search.." name="search" id="select">
                      <button type="submit" id="serch_btn"><i class="fa fa-search"></i></button>
                      <br><br><br>

      <div class="table-responsive">
      <table class="table table-striped">
      
      <tr>
        <td>Case Number</td>
        <td>First Name </td>
        <td>Last Name </td>
        <td>E-mail   </td>
        <td>Contact Number   </td>
            
         <td>View for Update</td>
         
         

        
      </tr>
      <?php $__currentLoopData = $casefiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $casefile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
      <tr>
        <td><?php echo e($casefile->case_num); ?> </td>
        <td><?php echo e($casefile->first_name); ?></td>
        <td><?php echo e($casefile->last_name); ?>     </td>
        <td><?php echo e($casefile->identity); ?>  </td>
        <td><?php echo e($casefile->phone); ?> </td>
        
        

        <td>
         <button class="btn_eye"><i class="fa fa-eye"></i></button>
         
       </td>
       
      
               </tr>     
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
              
        </div>    
      
    </div>
  </form>
          </div>
        </div>
      
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
   
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <script src="css/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="css/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="css/jquery.dcjqaccordion.2.7.js"></script>
  <script src="css/jquery.scrollTo.min.js"></script>
  <script src="css/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="css/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
