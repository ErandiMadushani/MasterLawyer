<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer About us</title>
	<link rel="stylesheet" type="text/css" href="css/style2.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
			<li><a href="/welcome">Home</a></li>
				<li><a href="/practices">Basic Law</a></li>
				<li><a href="/aboutus">About Us</a></li>
				<li><a href="/loginform">Login</a></li>
				

		<div class="title">
			<h2>About Us</h2>
		</div>

</header>


<div class="content">
				
			<p> 

KPPB LAW helps clients navigate the life cycle of business challenges. We are a full-service, mid-size law firm with attorneys experienced in handling the issues that companies face. We have a diverse legal team with deep roots in South Asian and other immigrant communities. View all of our business service areas. </p>
<br>
<h1>Business Focused. Value Driven. Global Reach.</h1>
<br>
<p>Since 2003, we have served as a legal partner for small- to mid-cap companies, and guided them through a wide-range of legal matters, business disputes and transactions as they grow and or face setbacks. Our clients are corporations, government entities, entrepreneurs, business owners, banks, lenders and brokers in the U.S. and multinational entities, with a particular emphasis on companies originating from the subcontinent of India. We counsel clients in various industry sectors including hospitality, information technology, commercial real estate, banking, franchising, manufacturing, life sciences/biosciences, pharmaceuticals, Fintech and healthcare.

KPPB LAW attorneys in Atlanta, GA; Houston, TX; New York, NY; and Gainesville, VA, bring over 10 decades of collective experience as corporate counsel, transactional attorneys, lender’s counsel and commercial litigators to help resolve local and multinational business challenges.

In addition to English, our attorneys speak Gujarati, Hindi, Bengali, Korean, Mandarin, Marathi, Punjabi, Spanish and Urdu. KPPB LAW is certified as a Minority Business Enterprise by the National Minority Supplier Development Council (NMSDC) and AV rated by Martindale Hubbell. We are a proud member of the National Association of Minority and Women Owned Law Firms.

We strive to bring value to our clients and our fees are structured to reduce the stress related to traditional law firm billing. We work with our clients to design a billing model that best suits your business needs, including flat fees, monthly retainers and hybrid fees, when appropriate.

Contact us to explore how we can help you and your business in the U.S. or abroad.
</p>
<br>
<h1>KPPB LAW in the Community</h1>
<br>
<p>KPPB LAW is active with a variety of business, legal and community organizations:</p>
	
		</div>
<br><br>


<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>

</body>
</html>