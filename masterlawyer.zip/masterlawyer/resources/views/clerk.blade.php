<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Master Lawyer</title>

  
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    
	


      <style>
             display-flex, .display-flex, .display-flex-center {
  display: flex;
  display: -webkit-flex; 
}

list-type-ulli {
  list-style-type: none;
  margin: 0;
  padding: 0; 
}

@font-face {
  font-family: 'Montserrat';
  font-style: normal;
  font-weight: 300;
  src: url("../fonts/montserrat/Montserrat-Light.ttf");
}

figure {
  margin: 0; 
}

p {
  margin-bottom: 0px;
  font-size: 15px;
  color: #777; 
}

h2 {
  line-height: 1.66;
  margin: 0;
  padding: 0;
  font-weight: 900;
  color: #222;
  font-family: 'Montserrat';
  font-size: 24px;
  text-transform: uppercase;
  text-align: center;
  margin-bottom: 40px; 
}

.clear {
  clear: both; 
}

body {
  font-size: 14px;
  line-height: 1.8;
  color: #222;
  font-weight: 400;
  font-family: 'Montserrat';
  background-image:linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3)), url("img/83.jpg");
  background-repeat: no-repeat;
  background-size: 100% 100%;
  background-position: center;
  padding: 115px 0; 
  width: 100%;
  height: auto;
  background-attachment: fixed;
}

.container {
  width: 660px;
  position: relative;
  margin: 0 auto;

}

.position-center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.signup-content {
  background: #fff;
  border-radius: 10px;
  padding: 50px 85px; 
  background-color: transparent;
}

.form-title{
	color: #fff;
	font-family: 'Century Gothic'; 
	font-size: 30px;
    font-weight: bold;
}

.form-group {
  overflow: hidden;
  margin-bottom: 20px; 
}

.form-input, select {
  width: 100%;
  height:40px;
  border: 1px solid #ebebeb;
  border-radius: 5px;
  padding: 12px 15px;
  box-sizing: border-box;
  font-size: 13px;
  font-weight: 500;
  color: #222; 
  background-color:lavender;
}

select{
	height:45px;
}

.form-input:focus {
    border: 1px solid transparent;
    border-image-slice: 1;
    border-radius: 5px;
    background-origin: border-box;
    background-clip:border-box;
}

.form-submit {
  width: 100%;
  border-radius: 5px;
  padding: 13px 20px;
  box-sizing: border-box;
  font-size: 14px;
  font-weight: 700;
  color: black;
  text-transform: uppercase;
  border: none; 
  background-image: linear-gradient(to left, #74ebd5, #9face6);
}

.form-submit:hover{
	text-decoration:underline;
	color:blue;
}

.loginhere {
  font-size: 20px;
  color: #fff;
  font-weight: 700;
  text-align: center;
  margin-top: 70px;
  margin-bottom: 5px; 
}

.loginhere-link {
  font-weight: 700;
  color: white;
  text-decoration: none; 
}

a:focus, a:active, a:hover {
  text-decoration: underline;
  outline: none;
  color: yellow;
}

.field-icon {
  float: right;
  margin-right: 17px;
  margin-top: -32px;
  position: relative;
  z-index: 2;
  color: #555; 
}

#ifYes{
		display:none;
}

#ifYes2{
		display:none;
}

label{
	color:#fff;
	font-size:16px;
	font-family:sans-serif;
}

.option{
	height:50px;
	font-size:20px;
}

#gender{
	color:#fff;
	font-size:16px;
}

#fmale{
	margin-left:200px;
	margin-top:0px;
}

@media screen and (max-width: 768px) {
  .container {
    width: calc(100% - 30px);
    max-width: 100%; } 
}
@media screen and (max-width: 480px) {
  .signup-content {
    padding: 40px 25px; } 
}

	 
      </style>
	  
    <script>
    function yesnoCheck(that) {
        if (that.value == "Lawyer") {
            //alert("check");
            document.getElementById("ifYes").style.display = "block";
        } 
		else if (that.value == "Customer") {
            //alert("check");
            document.getElementById("ifYes2").style.display = "block";
			document.getElementById("ifYes").style.display = "none";
        } 
		else{
			document.getElementById("ifYes").style.display = "none";
			document.getElementById("ifYes2").style.display = "none";
		}
		
    }
</script>


</head>
<body>

    <div class="main">

        <section class="signup">
            
            <div class="container">
                <div class="signup-content">
                <div class="left-box">
      
@if ($errors->any())
<div class="alert alert-danger">
  <ul>
    @foreach ($errors->all() as $error)
      <li>{{ $error }}</li>
    @endforeach
  </ul>
</div>
@endif
@if(session()->has('message'))
<div class="alert alert-success">
{{session()->get('message')}}
</div>
@endif
      
      <form class="form-horizontal" method="post" action="{{route('signupnew')}}">
      {{csrf_field()}} 
                        
                        <h2 class="form-title">Create Your Account</h2>

                        <div class="form-group">
							<select onchange="yesnoCheck(this);" name="role">
								
									<option value="Select">Select who you are?</option>
								
									<option value="Customer"  style="font-size:15px">I'm a Customer</option>
								
						</select>
                        </div>
                        

                        <div class="form-group">
							<label>First Name</label>
                            <input type="text" class="form-input" name="first_name"/>
                        </div>
						<div class="form-group">
							<label>Last Name</label>
                            <input type="text" class="form-input" name="last_name"/>
                        </div>
                        <div class="form-group">
							<label>Address line 1</label>
                            <input type="text" class="form-input" name="no" placeholder="Home number"/>
                        </div>
                        <div class="form-group">
							<label>Address Line 2</label>
                            <input type="text" class="form-input" name="street" placeholder="Street"/>
                        </div>
                        <div class="form-group">
							<label>Address Line 3</label>
                            <input type="text" class="form-input" name="city"/>
                        </div>
                        <div class="form-group" >
							<label>Date Of Birth</label>
                            <input type="Date" class="form-input" name="dob" style="color: gray"/>
                        </div>
                        <div class="form-group">
							<label>NIC</label>
                            <input type="text" class="form-input" name="nic"/>
                        </div>
                        
						<div>
						<label>Gender</label>
						<div id="gender">
						<input type="radio" name="gender" value="male"> Male
						<input id="fmale" type="radio" name="gender" value="female"> Female<br>
						</div>
						</div><br/>
						
						<div class="form-group">
							<label>E-mail</label>
                            <input type="email" class="form-input" name="email" placeholder="example@gmail.com"/>
                        </div>
                        <div class="form-group">
							<label>Contact Number</label>
                            <input type="text" class="form-input" name="phone"/>
                        </div>
                        <div class="form-group">
							<label>Username</label>
                            <input type="text" class="form-input" name="user_name"/>
                        </div>
                        <div class="form-group">
							<label>Password</label>
                            <input type="password" class="form-input" name="password"/>
                        </div>
                        <div id="ifYes">
							<label>Registration Number</label>
							<input type="text" class="form-input" name="regno"/><br/><br/>
						</div>
						
						<div id="ifYes2">
							<label>Select Your Lawyer</label>
							<select name="lawyer">
              <option value="Shihan"  style="font-size:15px"></option>
									<option value="Shihan"  style="font-size:15px">Shihan Chathuranga</option>
									<option value="Lasun"  style="font-size:15px">Lasun Basnayake</option>
									<option value="Subhashini"  style="font-size:15px">Subhashini Jayawardhana</option>
									<option value="Kasun"  style="font-size:15px">Kasun Gunarathne</option>
								
						</select>
            
							<label>Case Description</label>
                            <input type="textarea" class="form-input" name="desc"/>
                      
						</div>

                        <br/>
                        <div class="form-group">
                            <input type="submit" name="submit" class="form-submit" value="Sign up"/>
                        </div>
                    </form>
                    <p class="loginhere">
                        Have already an account ? <br/><a href="signIn.html" class="loginhere-link">Login here</a>
                    </p>
                </div>
            </div>
        </section>

    </div>

  </body>
</html>