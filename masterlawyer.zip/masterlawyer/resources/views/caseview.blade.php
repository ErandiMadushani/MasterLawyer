<!DOCTYPE html>
<html>
<head>
   <title>Master Lawyer</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <script src="bootstrap-3.3.6-dist/js/bootstrap.bundle.min.js"></script>
   <script src="bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="bootstrap-3.3.6-dist/css/bootstrap.min.css">
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
   
    <style>
      *{
	    box-sizing:border-box;
	  
	  }
      [class*="col-"] {
    float: left;
    padding: 20px;
	
	}
	
	
	 h6{
	    font-size: 16px;
           font-weight: bold;
          
	
	}
	#solid {
        border-style: solid;
        border-radius: 5px;
        background-color: #e1e8f4;
        border-width: 1px;
        padding-top: 15px;
        border-color: white;
        padding-right: 5px;
		padding:25px;
       
       }
	   
	   #Fname{

           padding-left: 15px;
           margin-left: 80px;
           margin-right: 100px;
           height: 30px;
           width: 265px;
           border-style: none;
       }
	   input{
	      margin-left:15px;
	   }
	   #b{
	      margin-left:650px;
	   }
	   .side_navi{
	   
	     background-color:#22242a;
		 width:1450px;
		 height:45px;
		 margin-top:0px;
		 padding-top:5px;
		 padding-left:100px;
		 padding-top:0px;
	   }

	    a.logo {
    font-size: 24px;
    color: #f2f2f2;
    float: left;
    margin-top: 10px;
    text-transform: uppercase;
	padding-left:-5px;
}

a.logo b {
    font-weight: 900;
}

a.logo:hover, a.logo:focus {
    text-decoration: none;
    outline: none;
}

a.logo span {
    color: #4ECDC4;
}

 #bt{
     margin-left:880px;
	 margin-top:5px;
 }

  .content{
       margin-left:80px;
  }
  hr{
  
     color:black;
	 
  }
  h2{
      text-align:center;
  }
	
		
   .col-1 {width: 8.33%;}
.col-2 {width: 16.66%;}
.col-3 {width: 25%;}
.col-4 {width: 33.33%;}
.col-5 {width: 41.66%;}
.col-6 {width: 50%;}
.col-7 {width: 58.33%;}
.col-8 {width: 66.66%;}
.col-9 {width: 75%;}
.col-10 {width: 83.33%;}
.col-11 {width: 91.66%;}
.col-12 {width: 100%;}
   @media only screen and (max-width:768px){
        [class*="col-"]{
		   width:100%;
		}
   
   }
   
   </style>
   
   </head>
<body>

<div id="content">
	 <div class="row col-md-12">
	    
	    
		<div class="side_navi col-md-1">
		     <a href="index.html" class="logo"><b>Master<span>Lawyer</span></b></a>
			 
		
             <a  id="bt" class="btn btn-primary" href="{{route('logout')}}">Logout</a></button>
			 </div>
	    
		
        
		</div>
		<div class="content col-md-8">
		    <div class="container">
			
			<hr>	
			<h2>View New Case Details</h2></br>
			
			<form class="form-horizontal" action="/action_page.php">
                            
            
      <div class="form-group" id="solid">
          
                <br>

                <br><br>
               
                <h6> First Name : </h6><br>
                <input type="text" class="form-control"  placeholder="" name="first_name" value="{{$casedata->first_name }}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	
                
                <h6> Last Name : </h6><br>         
                <input type="text" class="form-control"  placeholder="" name="last_name" value="{{$casedata->last_name }}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	

                <h6> E-mail : </h6><br>
                <input type="text" class="form-control"  placeholder="" name="email" value="{{$casedata->email }}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	

                 <h6> Date :  </h6><br>
                 <input type="text" class="form-control"  placeholder="" name="	created_at" value="{{$casedata->	created_at }}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	

                 <h6> Address :  </h6><br>
                
                 <input type="text" class="form-control"  placeholder="" name="city" value="{{$casedata->city }}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	

                <h6> Contact Number : </h6><br>
                <input type="text" class="form-control"  placeholder="" name="phone" value="{{$casedata->phone}}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	

                <h6> Description : </h6><br>
                <input type="text" class="form-control"  placeholder="" name="desc" value="{{$casedata->desc}}"/></br>
                <input type="hidden" name="id" value="{{$casedata->id}}"/>	
            
                <div class="form-group">        
			<div class="update">
			
			<button id="back" type="submit" class="btn btn-primary">Back</button>
			
			</div>
    </div>

  </form>
			
		<div class=" foot col-md-2">	
		</div>
 
		</div>
		
		
	</div> 



</body>
</html>