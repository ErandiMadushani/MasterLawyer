<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="Dashboard">
  <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
  <title>Master Lawyer</title>

  
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!--external css-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet">
  <link href="css/style-responsive.css" rel="stylesheet">




      <style>
              td{

              color: black;
              font-weight: bold;

           }


      </style>
 
</head>

<body>
  <section id="container">
    
    <!--header start-->
    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
      </div>
      <!--logo start-->
      <a href="index.html" class="logo"><b>Master<span>Lawyer</span></b></a>
      <!--logo end-->
      <div class="nav notify-row" id="top_menu">
        
      </div>
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
        <li><a class="logout" href="{{route('logout')}}">Logout</a></li>
        </ul>
      </div>
    </header>
    <!--header end-->
    
    <!--sidebar start-->
    <aside>
      <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
          <p class="centered"><a href="profile.html"><img src="img/ui-sam.jpg" class="img-circle" width="80"></a></p>
          @if( auth()->check() )
          <h5 class="centered">{{ auth()->user()->first_name }} {{ auth()->user()->last_name }}</h5>
          <li class="mt">
          @endif
            <a href="index.html">
              <i class="fa fa-home"></i>
              <span>Home</span>
              </a>
          </li>
		 
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Cases</span>
              </a>
            <!-- <ul class="sub">
              <li><a href="grids.html">Criminal</a></li>
              <li><a href="calendar.html">Civil</a></li>
              <li><a href="gallery.html">Divoce</a></li>
              <li><a href="todo_list.html">Case 01</a></li>
              
            </ul> -->
          </li>
          <li class="sub-menu">
            <a class="active" href="javascript:;">
              <i class="fa fa-book"></i>
              <span>Conveyance</span>
              </a>
            <ul class="sub">
            <li class="active"><a href="/convey">Print </a></li>
              <li class="active"><a href="/giftdeed">Gift Deed</a></li>     
              <li><a href="/uploadimage">Image of Deed</a></li>
              
            </ul>
          </li>
          <li class="sub-menu">
            <a href="javascript:;">
              <i class="fa fa-tasks"></i>
              <span>Evidance</span>
              </a>
            <ul class="sub">
              <li><a href="form_component.html">E 01</a></li>
              <li><a href="advanced_form_components.html">E 02</a></li>
              <li><a href="form_validation.html">E 03</a></li>
              <li><a href="contactform.html">E 04</a></li>
            </ul>
          </li>
          <li class="sub-menu">
            <a href="Lawyer_side_diary.html">
              <i class="fa fa-book"></i>
              <span>Law Diary</span>
              </a>
            
          </li>
          <li>
            <a href="inbox.html">
              <i class="fa fa-envelope"></i>
              <span>Mail </span>
              <span class="label label-theme pull-right mail-info">2</span>
              </a>
          </li>
         
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside>
    <!--sidebar end-->
   
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper site-min-height">
        <h3>  Requests</br></h3>
        <div class="row mt">
          <div class="col-lg-12">
          
     
     <form class="form-horizontal" >
      
      <div class="form-group">
      <div class="table-responsive">
      
      <table class="table table-striped">
      
      <tr>

       
        
        <td>First name </td>
        <td>Last name </td>
        <td>Identity </td>
        <td>Username    </td>       
        <td>Status   </td> 
        <td>Phone Number    </td> 
             
        <td>Role   </td>
        <td></td>     
        <td>Action</td>
        <td></td>

        
      </tr>
      
      @foreach($users as $user)
      <tr>    
     
       
        <td>{{$user->first_name}} </td>
        <td>{{$user->last_name}} </td>
        <td>{{$user->nic}} </td>
        <td>{{$user->user_name}}</td>
        <td>{{$user->active}} </td>      
        <td>{{$user->phone}}  </td>        
        <td>{{$user->role}}</td>       
       
       
      
        <td>
        <a href="/viewtask/{{$user->id}}" button class="btn_eye"  ><i class="fa fa-eye" ></i> </button></a>
       </td>
       <td><button class="btn_check"><i class="fa fa-check" href=></i></button>
                </td>
       
                <td>        
         <a class="btn btn-danger" onclick="return confirm('Do You want to delete?')" href="/deletetask/{{$user->id}}"><i class="fa fa-close"></i></a>
                </td>
             
        
      </tr>
      @endforeach
      </table>
      
      
      
    </div>
  </form>
          </div>
        </div>
      </section>
      <!-- /wrapper -->
    </section>
    <!-- /MAIN CONTENT -->
    <!--main content end-->
   
  </section>
  <!-- js placed at the end of the document so the pages load faster -->
  <script src="css/jquery.min.js"></script>
  <script src="css/bootstrap.min.js"></script>
  <script src="css/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="css/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="css/jquery.dcjqaccordion.2.7.js"></script>
  <script src="css/jquery.scrollTo.min.js"></script>
  <script src="css/jquery.nicescroll.js" type="text/javascript"></script>
  <!--common script for all pages-->
  <script src="css/common-scripts.js"></script>
  <!--script for this page-->

</body>

</html>
