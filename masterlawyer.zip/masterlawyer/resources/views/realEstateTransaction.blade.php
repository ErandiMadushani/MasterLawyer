<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer Real Estate Transaction</title>
	<link rel="stylesheet" type="text/css" href="css/style12.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
			<li><a href="/welcome">Home</a></li>
				<li><a href="/practices">Basic Law</a></li>
				<li><a href="/aboutus">About Us</a></li>
				<li><a href="/loginform">Login</a></li>

		<div class="title">
			<h2>Real Estate Transaction</h2>
		</div>

</header>


<div class="content">
				
			<p> 

When your company is struggling to make commercial loan payments or diverting what should be working capital to manage outstanding debt, your whole business may suffer. Our law firm offers a range of legal services designed to assist businesses with commercial loan workouts so they can move forward on stronger footing. Of course, attaining a beneficial commercial loan workout requires the cooperation of your lender, which is not always easy to secure. Our experienced attorneys put their extensive knowledge of commercial real estate loans to work for our clients, and have a proven record of success in securing commercial loan workouts.
<br><br>
<h2>Commercial Loan Workouts Legal Services</h2><br>
When it comes to commercial loan workouts, our firm provides a full range of legal services, including:
<br><br>
<h2>Pre-Default Negotiations and Post-Default Negotiations</h2><br>
Loan Modification<br>
Forbearance Agreement<br>
Deed in Lieu of Foreclosure<br>
Receivership<br>
Managing Purchase and Sale of Pre-Foreclosure Properties<br>
Managing Purchase and Sale of Short Sale Properties<br>
Pre-Default Negotiations and Post-Default Negotiations<br><br>
Commercial Loan WorkoutsIn situations where a business has defaulted or will default on a commercial loan, an attorney can provide assistance in negotiating with a bank or lender to achieve a settlement. The circumstances of the loan, primarily how well secured the loan is, will impact the lender’s flexibility and play a role in the range of options available. An attorney with a thorough understanding of banking, debt collection, securitization and finance law can guide your organization through the often-complicated process and negotiate on your behalf to achieve the best possible results.
<br><br>
Our attorneys also have insight into the priorities and motivations of banks and other mortgagees, and are thus well-positioned to negotiate effectively. With a favorable lump-sum settlement or a new payment plan secured, you will once again have the freedom to focus on operating and growing your business.
<br><br>
<h2>Loan Modification</h2><br>
When a business has trouble making payments on a commercial loan, a loan modification may be the answer. An experienced commercial loan modification attorney can assess the agreements and transaction history for leverage such as contract or legal violations. At the same time, the attorney can take parallel steps to give your company the time required to negotiate for a loan modification.
<br><br>
Foreclosure can devastate a business, but alternative resolutions are often available. Given the complexity of banking and debt collection laws and the delicacy of the negotiation process, obtaining assistance from an attorney experienced in this arena is typically the best way to modify a commercial loan.
<br><br>
<h2>Forbearance Agreement</h2><br>
Commercial Loan WorkoutsA forbearance agreement allows the lender to preserve its rights while allowing the business time to cure the default. Typically, a lender will be more likely to agree to a forbearance in a situation where foreclosure is not likely to be profitable, such as when the loan is undersecured. Under a forbearance agreement, the lender agrees to delay foreclosure for a specified time period in exchange for the borrower taking some type of action to cure the default. Depending on the specifics of the loan and the property in question, this may include listing the property for sale, liquidating other assets to bring the loan current, or securing alternative financing.
<br><br>
However, a borrower entering into a forbearance agreement without knowledgeable legal advice may inadvertently compromise important legal rights. An experienced commercial real estate lawyer can assess the underlying facts of the mortgage to determine whether there is a legal defense to foreclosure, and counsel for or against signing a forbearance agreement on that basis. If forbearance is the right answer, having an attorney at the table when negotiating a forbearance agreement often results in far more favorable deals for clients.
<br><br>
<h2>Deed in Lieu of Foreclosure</h2><br>
While most commercial real estate loan solutions are geared toward preventing foreclosure, there are some circumstances under which it is preferable for the company to move or to consolidate operations and free itself from the ongoing payment obligation. In many cases, there is a better way to achieve that result than standing by and allowing the lender to foreclose. A deed in lieu of foreclosure may allow the company to walk away from its commercial real estate loan with less complication and less expense. The lender will often agree because this process wraps up the transaction more quickly and saves the expense of a foreclosure action. When a borrower and lender agree to a deed in lieu of foreclosure, the borrower signs the deed to a property over to the lender in satisfaction of the loan.
<br><br>
An experienced attorney can ensure that the borrower’s rights are preserved in the transaction, and can negotiate for favorable terms such as a reduction or write-off of any deficiency balance.
<br><br>
<h2>Receivership</h2><br>
Commercial mortgage agreements commonly contain a provision that allows the lender to appoint a receiver upon certain triggering events. It is important that a company entering into a commercial mortgage is aware of and understands the circumstances that may trigger appointment of a receiver, and that a company finding itself unable to keep mortgage payments current gets advice as to its options and the likelihood that a receiver will be appointed as soon as possible.
<br><br>
Receivers are most frequently appointed when the property is income-generating. For example, if the owner of an apartment complex defaults on the mortgage, the lender may pursue appointment of a receiver to manage the property and collect rents. If your organization is facing commercial property receivership, an experienced commercial real estate lawyer can explain the options available to you and help to ensure that your interests are protected.
<br><br>
<h2>Managing Purchase and Sale of Pre-Foreclosure Properties</h2><br>
Like a deed in lieu of foreclosure, pre-foreclosure sales may provide a means of resolving the outstanding debt while allowing both the borrower and the lender to avoid costly and time-consuming legal procedures. Whether you are an investor seeking to purchase property in advance of foreclosure or a commercial real estate borrower hoping to avoid foreclosure by selling the property, a veteran commercial real estate lawyer can be your best resource.
<br><br>
The terms of a pre-foreclosure sale will dictate important details such as the amount you may be required to pay over and above the sale price, or how long your company will be able to retain possession of the property after negotiating the sale.
<br><br>
<h2>Managing Purchase and Sale of Short Sale Properties</h2><br>
One of the key complications in commercial real estate today is that declining property values have created deficiencies in mortgage security. In simple terms, many commercial borrowers owe more on their mortgages than the property is worth. That creates obstacles for the organization that is having trouble keeping up mortgage payments, because a standard sale of the property would result in a deficiency balance.
<br><br>
In some cases, an experienced commercial real estate attorney may be able to negotiate for a short sale. In a short sale, all proceeds of the sale go to the lender, and the lender agrees to accept those proceeds in full satisfaction of the loan. The borrower is no longer responsible for the unpaid balance of the loan.
<br><br>
Short sale buyers and sellers alike will benefit from consultation with an experienced commercial real estate lawyer. It is important to fully understand the terms of the agreement, any rights you may be waiving, and the obligations that may arise from the short sale agreement and transfer of property.
<br><br>
<h2>Benefits of Our Commercial Loan Workouts Legal Services</h2><br>
If you are having difficulty making payments on a loan or mortgage, quality legal representation may save your property, or allow you to extricate yourself from an unmanageable contract and make profitable changes in your business operations. This area of law requires an in-depth understanding of banking, finance and debt collection laws on both the state and federal level. Our firm has significant experience handling commercial loan workout cases, and our attorneys use their considerable knowledge and experience to achieve the best possible result for our clients. When you entrust your commercial loan workout to our firm, you will receive guidance and advice throughout the process, ensuring that you will not feel overwhelmed by the legal process.
<br><br>
<h2>Contact Us Today</h2><br>
If you need advice or assistance on a commercial loan workout, do not hesitate to call our firm. Our lawyers are ready to assist you with all of your loan and mortgage legal issues. Their expert advice will give you peace of mind, knowing that your case is in capable hands. Contact KPPB LAW today to schedule an initial consultation!


		</div>
<br><br>


<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>

</body>
</html>