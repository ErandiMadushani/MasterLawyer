<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer Practices</title>
	<link rel="stylesheet" type="text/css" href="css/style3.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
				<li><a href="/welcome">Home</a></li>
				<li><a href="/practices">Basic Law</a></li>
				<li><a href="/aboutus">About Us</a></li>
				<li><a href="/loginform">Login</a></li>
				

		<div class="title">
			<h2>Practices</h2>
		</div>

</header>

<div class="criminallaw">
	<img src="img/41.png">
</div>

<div class="criminallawDetail">

	<a href="#">Criminal Law</a>
	<p>
		The real estate and secured lending attorneys at KPPB LAW have extensive knowledge and experience on a wide range of real estate and commercial lending issues. We regularly represent clients on real estate acquisitions and sales, financing and secured lending, construction, leasing, zoning and land use, regulatory matters including environmental issues, and the exercise of rights and remedies such as receiverships and foreclosures.
	</p>
</div>

<div class="civillaw">
	<img src="img/42.png">
</div>

<div class="civillawDetail">

	<a href="#">Civil Law</a>
	<p>
		The real estate and secured lending attorneys at KPPB LAW have extensive knowledge and experience on a wide range of real estate and commercial lending issues. We regularly represent clients on real estate acquisitions and sales, financing and secured lending, construction, leasing, zoning and land use, regulatory matters including environmental issues, and the exercise of rights and remedies such as receiverships and foreclosures.
	</p>
</div>

<div class="criminallaw">
	<img src="img/41.png">
</div>




<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>

</body>
</html>