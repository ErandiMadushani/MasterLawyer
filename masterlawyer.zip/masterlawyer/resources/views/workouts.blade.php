<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Master Lawyer Bankrupty & Workouts</title>
	<link rel="stylesheet" type="text/css" href="css/style9.css">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
</head>

<body onload="init()">

<header>
		
		<div class="main" id="mymain">			
			<ul>
			<li><a href="/welcome">Home</a></li>
				<li><a href="/practices">Basic Law</a></li>
				<li><a href="/aboutus">About Us</a></li>
				<li><a href="/loginform">Login</a></li>
				

		<div class="title">
			<h2>Bankrupty & Workouts</h2>
		</div>

</header>


<div class="content">
				
			<p> 

Our firm provides a variety of bankruptcy-related services, representing both debtors who are attempting to resolve financial issues and creditors whose accounts receivable are at risk due to someone else’s bankruptcy. While bankruptcy is often viewed as a matter of filling out forms, it is actually a complex legal process that can easily go wrong if the process is not guided by someone with an intimate knowledge of its complexities and possible pitfalls. Our attorneys have the experience necessary to successfully advise and represent you in the bankruptcy proceedings that may impact your business.
<br><br>
<h2>
Bankruptcy Law Services</h2>
<br><br>
You can count on our firm for reliable, knowledgeable bankruptcy law services in the following areas:
<br><br>
Chapter 7 Bankruptcy<br><br>
Chapter 11 Bankruptcy<br><br>
Purchasing Assets Out of Bankruptcy<br><br>
Representation of Creditor Committees<br><br>
Chapter 7 Bankruptcy<br><br>
Bankruptcy & WorkoutsChapter 7 bankruptcy is also known as “liquidation,” because the assets of a company are sold off for the benefit of creditors. Some corporations choose this route because the bankruptcy trustee handles the sale of assets and payment of creditors, reducing the burden on corporate leadership as the company wraps up.
<br><br>
In some cases, an owner of the corporation will have personal liability for the corporation’s debts, either by operation of law or because he or she served as a co-signer for the corporation. Personal liability may also be an issue in a sole proprietorship, partnership or other non-corporate entity. In these cases, the owner often opts to file for Chapter 7 bankruptcy personally, thus eliminating liability for the business’s debts.
<br><br>
Determining whether Chapter 7 is the best approach for a particular company and whether or not there is personal liability involved can be complicated, and an error could mean losing out on the value of assets or wrapping up the corporate process only to begin receiving collection calls as an individual. Working with an experienced business bankruptcy lawyer will help protect your financial interests.
<br><br>
<h2>Chapter 11 Bankruptcy</h2><br><br>
Unlike Chapter 7 bankruptcy, a Chapter 11 bankruptcy filing doesn’t put an end to a corporation. Instead, Chapter 11 bankruptcy gives businesses and individuals alike the opportunity to restructure debts in order to continue operations. The debtor company must present a Chapter 11 reorganization plan, along with other financial data.
<br><br>
One significant difference between Chapter 11 bankruptcy and other,more common, forms of bankruptcy is the role that creditors play in the proceedings. A creditor committee, comprised of the 7 largest unsecured creditors, plays an active role in development of the plan. And, creditors are divided into classes and have the opportunity to vote to approve or disapprove the plan.
<br><br>
Because of the active role creditors take, strategic negotiation plays a significant role in getting a Chapter 11 reorganization plan approved and beginning to address debt.
<br><br>
<h2>Purchasing Assets Out of Bankruptcy</h2><br><br>
Bankruptcy & WorkoutsBuying assets out of bankruptcy can mean a significant cost savings on equipment,inventory and other business assets. However, the process by which one purchases assets out of bankruptcy differs depending upon the type of bankruptcy. For example, in a Chapter 7 bankruptcy, the corporation will be entirely liquidated, meaning that all assets will be up for sale. However, the bankruptcy trustee is responsible for protecting the interests of the creditors, and so must approve any sale.
<br><br>
In a Chapter 11 case, the situation is less clear. The business will still be operating, meaning that there are certain types of sales which will be ongoing in the ordinary course of business. Other types of sales will require court approval.
<br><br>
Our attorneys are experienced in assisting companies with purchasing assets out of bankruptcy, and can advise you on the procedures required and assist with the process to help ensure a smooth transaction with no surprises.
<br><br>
<h2>Representation of Creditor Committees</h2><br><br>
Creditor committees can play an important role in ensuring that a company in Chapter 11 bankruptcy operates responsibly. The committee is typically made up of the debtor’s seven largest unsecured creditors. While the work of this committee protects their own interests, the interests of the other creditors and perhaps even the interests of the company itself, the responsibility can be daunting.
<br><br>
Fortunately, the creditor committee is empowered to hire professionals if necessary, including an attorney to represent and guide the committee. The cost of hiring such professionals is an allowable administrative expense, meaning that committee members are not responsible for the costs of obtaining legal assistance.
<br><br>
<h2>Advantages of Our Bankruptcy Law Services</h2><br><br>
If you’re considering bankruptcy for your company, it’s important that you get accurate information and reliable guidance before you take the next step. A seasoned business bankruptcy lawyer like the ones in our firm can help you assess whether a Chapter 7 liquidation or a Chapter 11 reorganization would best suit your purposes and advise as to whether there are personal liabilities involved. Then, our bankruptcy lawyers will manage the process for you, preparing documents, negotiating with creditors where necessary and otherwise eliminating stresses for your team and ensuring that you avoid common mistakes and pitfalls.
<br><br>
If you’re a creditor, you may need to act quickly to ensure that your rights are protected. You can’t afford to delay in getting the advice you need. Remember that if you’re a member of the unsecured creditor committee, you may be able to hire our firm to represent the committee without paying a dime from your own pockets.
<br><br>
<h2>Get the Bankruptcy Law Advice you Need – Contact Us Right Now</h2><br><br>
The experienced bankruptcy attorneys at our firm are ready to assist you with your bankruptcy needs, whether you’re a representative of a company overburdened by debt, a large creditor hoping to help steer a debtor back to solvency in order to collect what you’re owed or a new or growing company looking to purchase the assets of a bankrupt business.
<br><br>
Call us right now or send us a message online to get started. You’ll rest easier knowing that your legal matter is in capable hands.
		</div>
<br><br>


<div class="footer">
				<p class="contact">Contact us </p><br>
				<p><i class="fa"> &#xf095;  </i>&nbsp;&nbsp; &nbsp;   047 - 2245678</p><br>
				<p><i class="fa"> &#xf0e0;  </i>&nbsp;&nbsp;    masterlowyer@gmail.com</p><br>
				<p><i class="fa"> &#xf2bb;  </i>&nbsp;&nbsp;    Master Lawyer,
																No : 16,		
																Walasmulla </p>
				<br>
				<br>
				

</div>

</body>
</html>