<?php
use\App\User;
use\App\Giftdeed;
use\App\Message;
use\App\Payment;
use\App\Appointment;
use Illuminate\Support\Facades\Input;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');*/
    Route::group(['middleware'=>['web']], function(){
      
            Route::get('/',[
                'uses'=>'SignUpController@indexhome',
                'as'=>'welcome'
            ]);
            Route::get('/Signup',[
                'uses'=>'SignUpController@getSignup',
                'as'=>'signup'
                ]);
             
                    Route::post('/signup',[
                        'uses'=>'SignUpController@postSignUp',
                        'as'=>'signup'
                    ]);               
                    Route::post('/lawdiarynew',[
                        'uses'=>'SignUpController@postlawdiarynew',
                        'as'=>'lawdiarynew'
                    ]);   
                    Route::get('/welcome',[
                        'uses'=>'SignUpController@getwelcome',
                        'as'=>'welcome'
                        ]);
                        
                        Route::post('/login',[
                            'uses'=>'SignUpController@postLogin',
                            'as'=>'login'
                        ]);
                        Route::get('/admin',function(){
                            $user=App\User::all();
                            return view('admin')->with('users',$user);
                        });
                        Route::get('/admindash',[
                            'uses'=>'SignUpController@getadmindash',
                            'as'=>'admindash'                                                
                         ]);
                         Route::get('/admin',[
                            'uses'=>'SignUpController@getadmin',
                            'as'=>'admin'                                                
                         ]);    
                         Route::get('/adminapprove',[
                            'uses'=>'SignUpController@getadminapprove',
                            'as'=>'adminapprove'                                                
                         ]);                          
                         Route::get('/loginform',[
                            'uses'=>'SignUpController@getloginform',
                            'as'=>'loginform'
                            ]);
                            Route::get('/signup',[
                                'uses'=>'SignUpController@getsignup',
                                'as'=>'signup'
                                ]);
                                Route::post('/signupnew',[
                                    'uses'=>'SignUpController@postSignUp',
                                    'as'=>'signupnew'
                                ]);
                                Route::post('/savepayment',[
                                    'uses'=>'SignUpController@postsavepayment',
                                    'as'=>'savepayment'
                                ]);
                                Route::get('/clerk',[
                                    'uses'=>'SignUpController@getclerk',
                                    'as'=>'clerk'                    
                                 ]);
                                 Route::get('/adminsendmsg',[
                                    'uses'=>'SignUpController@getadminsendmsg',
                                    'as'=>'adminsendmsg'                    
                                 ]);
                                 Route::get('/adminmail',[
                                    'uses'=>'SignUpController@getadminmail',
                                    'as'=>'adminmail'                    
                                 ]);
                                 Route::GET('/lawyerdash',function(){
                                    $user=App\User::all();
                                    return view('lawyerdash')->with('users',$user);
                                });
                                 Route::GET('/lawyerdash',[
                                    'uses'=>'SignUpController@getlawyerdash',
                                    'as'=>'lawyerdash'                    
                                 ]);                                
                                 Route::get('/aboutus',[
                                    'uses'=>'SignUpController@getaboutus',
                                    'as'=>'aboutus'                    
                                 ]);
                                 Route::get('/user',[
                                    'uses'=>'SignUpController@getuser',
                                    'as'=>'user'                    
                                 ]);
                                 Route::get('/lawcustomer',[
                                    'uses'=>'SignUpController@getlawcustomer',
                                    'as'=>'lawcustomer'                    
                                 ]);
                                 Route::get('/practices',[
                                    'uses'=>'SignUpController@getpractices',
                                    'as'=>'practices'                    
                                 ]);
                                 Route::get('/lawdiary',[
                                    'uses'=>'SignUpController@getlawdiary',
                                    'as'=>'lawdiary'                    
                                 ]);
                                 Route::GET('/lawdiary',function(){
                                    $lawdiary=App\lawdiary::all();
                                    return view('lawdiary')->with('lawdiarys',$lawdiary);
                                });
                                 Route::get('/lawyerProfile',[
                                    'uses'=>'SignUpController@getlawyerProfile',
                                    'as'=>'lawyerProfile'                    
                                 ]);
                                 Route::get('/assetBased',[
                                    'uses'=>'SignUpController@getassetBased',
                                    'as'=>'assetBased'                    
                                 ]);
                                 Route::get('/workouts',[
                                    'uses'=>'SignUpController@getworkouts',
                                    'as'=>'workouts'                    
                                 ]);
                                 Route::get('/collection',[
                                    'uses'=>'SignUpController@getcollection',
                                    'as'=>'collection'                    
                                 ]);
                                 Route::get('/lawadminpay',[
                                    'uses'=>'SignUpController@getlawadminpay',
                                    'as'=>'lawadminpay'                    
                                 ]);
                                 Route::get('/commercialLaw',[
                                    'uses'=>'SignUpController@getcommercialLaw',
                                    'as'=>'commercialLaw'                    
                                 ]);
                                 Route::get('/realEstateTransaction',[
                                    'uses'=>'SignUpController@getrealEstateTransaction',
                                    'as'=>'realEstateTransaction'                    
                                 ]);
                                 Route::get('/contracts',[
                                    'uses'=>'SignUpController@getcontracts',
                                    'as'=>'contracts'                    
                                 ]);

                                 Route::get('/coparate',[
                                    'uses'=>'SignUpController@getcoparate',
                                    'as'=>'coparate'                    
                                 ]);
                                 Route::get('/readmessage',[
                                    'uses'=>'SignUpController@getreadmessage',
                                    'as'=>'readmessage'                    
                                 ]);
                                 Route::get('/payment',[
                                    'uses'=>'SignUpController@getpayment',
                                    'as'=>'payment'                    
                                 ]);
                                 Route::get('/crossBoader',[
                                    'uses'=>'SignUpController@getcrossBoader',
                                    'as'=>'crossBoader'                    
                                 ]);

                                 Route::get('/lawcustomer',function(){                                  
                                    $user = DB::table('users')->where('lawyer','=', Auth::user()->first_name)->get();                                
                                    return view('lawcustomer')->with('users',$user);
                                    
                                });    
                                
                                Route::get('/adminmail',function(){                                  
                                    $message = DB::table('messages')->where('lawyer','=', Auth::user()->first_name)->get();                                
                                    return view('adminmail')->with('messages',$message);
                                    
                                });   
                                Route::get('/readmessage',function(){                                  
                                    $message = DB::table('messages')->where('first_name','=', Auth::user()->first_name)->get();                                
                                    return view('readmessage')->with('messages',$message);
                                    
                                });                           
                     
                            
                                 Route::get('admindash',function(){
                                    $user=App\User::where('role','=','Lawyer')->get();                                 
                                    return view('admindash')->with('users',$user);
                                });
                                Route::get('clerk',function(){
                                    $user=App\User::where('role','=','Clerk')->get();                                   
                                    return view('clerk')->with('users',$user);
                                });
                                Route::get('/clerkdash',function(){
                                    $user=App\User::where('role','=','Clerk')->get();                                   
                                    return view('clerkdash')->with('users',$user);
                                });
                                Route::get('/customers',function(){
                                    $user=App\User::where('role','=','Customer')->get();                                   
                                    return view('customers')->with('users',$user);
                                });
                                Route::get('/cases',function(){
                                    $user=App\User::where('role','=','Customer')->get();                                   
                                    return view('cases')->with('users',$user);
                                });
                                Route::get('/logout',[
                                    'uses'=>'SignUpController@getLogout',
                                    'as'=>'logout'
                                ]);
                                Route::get('/giftdeed',[
                                    'uses'=>'SignUpController@getgiftdeed',
                                    'as'=>'giftdeed'
                                ]);
                                Route::get('/viewdaytask',[
                                    'uses'=>'SignUpController@getviewdaytask',
                                    'as'=>'viewdaytask'
                                ]);
                                Route::get('/uploadimage',[
                                    'uses'=>'SignUpController@getuploadimage',
                                    'as'=>'uploadimage'
                                ]);

                                Route::get('/convey',[
                                    'uses'=>'SignUpController@getconvey',
                                    'as'=>'convey'
                                ]);
                                Route::get('/sendmessagereq',[
                                    'uses'=>'SignUpController@getsendmessagereq',
                                    'as'=>'sendmessagereq'
                                ]);
                                Route::get('/payment02',[
                                    'uses'=>'SignUpController@getpayment02',
                                    'as'=>'payment02'
                                ]);
                                Route::get('/sendmessage',[
                                    'uses'=>'SignUpController@getsendmessage',
                                    'as'=>'sendmessage'
                                ]);
                                Route::get('/lawyermessage',[
                                    'uses'=>'SignUpController@getlawyermessage',
                                    'as'=>'lawyermessage'
                                ]);
                                Route::get('/clerkhome',[
                                    'uses'=>'SignUpController@getclerkhome',
                                    'as'=>'clerkhome'
                                ]);
                                Route::get('/addcasedata',[
                                    'uses'=>'SignUpController@getaddcasedata',
                                    'as'=>'addcasedata'
                                ]);
                                Route::post('/savedeed',[
                                    'uses'=>'SignUpController@postDeed',
                                    'as'=>'savedeed'
                                ]);
                                Route::post('/sendreq',[
                                    'uses'=>'SignUpController@postsendreq',
                                    'as'=>'sendreq'
                                ]);
                                Route::post('/saveimage',[
                                    'uses'=>'SignUpController@postImage',
                                    'as'=>'saveimage'
                                ]);
                                Route::post('/caseupdate',[
                                    'uses'=>'CaseController@postcaseupdate',
                                    'as'=>'caseupdate'
                                ]);
                                Route::POST('/messagenew',[
                                    'uses'=>'SignUpController@postmessagenew',
                                    'as'=>'messagenew'
                                ]);
                                Route::POST('/addmessagenew',[
                                    'uses'=>'SignUpController@postaddmessagenew',
                                    'as'=>'addmessagenew'
                                ]);
                                Route::POST('/lawdiaryaddcasedata',[
                                    'uses'=>'SignUpController@postlawdiaryaddcasedata',
                                    'as'=>'lawdiaryaddcasedata'
                                ]);
                                Route::get('/convey',function(){
                                    $giftdeed=App\Giftdeed::all();
                                    return view('convey')->with('giftdeeds',$giftdeed);
                                });
                                Route::get('/payment',function(){
                                    $user=App\User::where('role','=','Lawyer')->get();
                                    return view('payment')->with('users',$user);
                                });
                                Route::get('/updatecasedetail',function(){
                                    $casefile=App\Casefile::all();
                                    return view('updatecasedetail')->with('casefiles',$casefile);
                                });
                                Route::get('/clerkconvey',function(){
                                    $giftdeed=App\Giftdeed::all();
                                    return view('clerkconvey')->with('giftdeeds',$giftdeed);
                                });
                                Route::get('/lawpay',function(){
                                    $payment = DB::table('payments')->where('first_name','=', Auth::user()->first_name)->get();
                                    return view('lawpay')->with('payments',$payment);
                                });
                                Route::get('/lawadminpay',function(){
                                    $payment = DB::table('payments')->where('first_name','=', Auth::user()->first_name)->get();
                                    return view('lawadminpay')->with('payments',$payment);
                                });
                                Route::get('/viewdaytask',function(){
                                    $lawdiary = DB::table('lawdiaries')->where('lawyer','=', Auth::user()->first_name)->get();
                                    return view('viewdaytask')->with('lawdiaries',$lawdiary);
                                });
                                Route::get('adminapprove',function(){
                                    $user=App\User::where('role','=','Lawyer')->get();
                                    return view('adminapprove')->with('users',$user);
                                });
                                Route::get('sendmessagereq',function(){
                                    $user=App\User::where('role','=','Lawyer')->get();                               
                                    return view('sendmessagereq')->with('users',$user);
                                });
                                Route::get('/makeadmin',function(){
                                    $user=App\User::where('role','=','Lawyer')->get();
                                    return view('makeadmin')->with('users',$user);
                                });
                                Route::get('/clerkapprove',function(){
                                    $user=App\User::where('role','=','Clerk')->get();
                                    return view('clerkapprove')->with('users',$user);
                                });
                                Route::get('/customerapprove',function(){
                                    $user=App\User::where('role','=','Customer')->get();
                                    return view('customerapprove')->with('users',$user);
                                });
                                Route::post('/paymenttasks','SignUpController@paymenttask');
                                Route::get('/updatepay/{id}','SignUpController@updatepays');
                                Route::get('/viewtask/{id}','SignUpController@viewtasks');
                                Route::get('/viewtaskmessage/{id}','SignUpController@viewtaskmessages');
                                Route::get('/viewtaskcusmessage/{id}','SignUpController@viewtaskcusmessages');
                                Route::get('/viewcase/{id}','SignUpController@viewcases');
                                Route::get('/viewcaseup/{id}','SignUpController@viewcasesup');
                                Route::get('/conveyview/{id}','SignUpController@conveyviewtasks');
                                Route::get('/deletetask/{id}','SignUpController@deletetask');
                                Route::get('/deletecustask/{id}','SignUpController@deletecustask');
                                Route::get('file','SignUpController@create');
                                Route::post('file','SignUpController@store');
                                Route::get('/markasapproved/{id}','SignUpController@updateTaskAsCompleted');
                                Route::get('/markasreject/{id}','SignUpController@updateTaskAsNotCompleted');
                                Route::get('/markasadmin/{id}','SignUpController@updateTaskAsadminCompleted');
                                Route::get('/markasrejectadmin/{id}','SignUpController@updateTaskAsNotadminCompleted');
                                Route::any('/search',function(){
                                    $q = Input::get ( 'q' );
                                    $giftdeed = Giftdeed::where('deed_number','LIKE','%'.$q.'%')->orWhere('donarname','LIKE','%'.$q.'%')->get();
                                    if(count($giftdeed) > 0)
                                        return view('convey')->withDetails($giftdeed)->withQuery ( $q );
                                    else return view ('convey')->withMessage('No Details found. Try to search again !');
                                });
                                Route::any('/search02',function(){
                                    $p = Input::get ( 'p' );
                                    $lawdiary = lawdiary::where('nextDate','LIKE','%'.$p.'%')->get();
                                    if(count($lawdiary) > 0)
                                        return view('viewdaytask')->withDetails($lawdiary)->withQuery ( $p );
                                    else return view ('viewdaytask')->withMessage('No Details found. Try to search again !');
                                });
                                Route::get('/logout',[
                                    'uses'=>'SignUpController@getLogout',
                                    'as'=>'logout'
                                ]);
});
